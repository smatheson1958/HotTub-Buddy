import { useColorScheme } from "react-native";

export default function useTheme() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";

  const colors = {
    isDark,
    background: isDark ? "#000000" : "#f0f2f5",
    surface: isDark ? "#111827" : "#FFFFFF",
    surfaceElevated: isDark ? "#1F2937" : "#F3F4F6",
    surfaceHighest: isDark ? "#111827" : "#F9FAFB",
    text: isDark ? "#F9FAFB" : "#111827",
    textSecondary: isDark ? "#9CA3AF" : "#4B5563",
    textTertiary: isDark ? "#6B7280" : "#9CA3AF",
    primary: "#3B82F6",
    primaryGradientStart: "#3B82F6",
    primaryGradientEnd: "#2563EB",
    border: isDark ? "#374151" : "#E5E7EB",
    notification: "#EF4444",
    success: "#10B981",
    warning: "#F59E0B",
    warningBackground: isDark ? "rgba(245, 158, 11, 0.2)" : "#FEF3C7",
    hydration: "#60A5FA",
    fitness: "#10B981",
    calories: "#F87171",
    nutrition: "#818CF8",
    categoryActive: "#3B82F6",
    categoryActiveText: "#FFFFFF",
  };

  return { colors, isDark };
}
