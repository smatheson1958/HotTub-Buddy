import { useAuth } from "@/utils/auth/useAuth";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { useEffect, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Platform, Dimensions } from "react-native";
import DisclaimerModal from "@/components/DisclaimerModal";
import useDisclaimerAcceptance from "@/utils/useDisclaimerAcceptance";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 30, // 30 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

export default function RootLayout() {
  const { initiate, isReady } = useAuth();
  const [minTimeElapsed, setMinTimeElapsed] = useState(false);
  const {
    hasAccepted,
    isLoading: isDisclaimerLoading,
    acceptDisclaimer,
  } = useDisclaimerAcceptance();
  const [showDisclaimer, setShowDisclaimer] = useState(false);

  useEffect(() => {
    initiate();
  }, [initiate]);

  // Start 3-second timer when component mounts
  useEffect(() => {
    const timer = setTimeout(() => {
      setMinTimeElapsed(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  // Show disclaimer modal if not accepted yet
  useEffect(() => {
    if (!isDisclaimerLoading && !hasAccepted) {
      setShowDisclaimer(true);
    }
  }, [isDisclaimerLoading, hasAccepted]);

  // Hide splash screen only after all conditions are met
  useEffect(() => {
    if (isReady && minTimeElapsed && !isDisclaimerLoading && hasAccepted) {
      SplashScreen.hideAsync();
    }
  }, [isReady, minTimeElapsed, isDisclaimerLoading, hasAccepted]);

  const handleAcceptDisclaimer = async (version) => {
    await acceptDisclaimer(version);
    setShowDisclaimer(false);
  };

  if (!isReady || isDisclaimerLoading) {
    return null;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <DisclaimerModal
          visible={showDisclaimer}
          onAccept={handleAcceptDisclaimer}
        />
        <Stack screenOptions={{ headerShown: false }} initialRouteName="index">
          <Stack.Screen name="index" />
        </Stack>
      </GestureHandlerRootView>
    </QueryClientProvider>
  );
}
